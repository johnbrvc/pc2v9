#
# File:    hello.rb
# Purpose: to print hello world in Ruby
# Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
#

puts "Hello World.\n";

# eof $Id$
